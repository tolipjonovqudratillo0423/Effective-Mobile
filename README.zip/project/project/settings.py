from pathlib import Path
from datetime import timedelta

from django.conf.global_settings import AUTH_USER_MODEL
from decouple import config
# =========================================================
# BASE
# =========================================================

BASE_DIR = Path(__file__).resolve().parent.parent



# =========================================================
# SECURITY
# =========================================================

SECRET_KEY = config("SECRET_KEY")

DEBUG = config("DEBUG", cast=bool)

ALLOWED_HOSTS = ["127.0.0.1"]



# =========================================================
# APPLICATIONS
# =========================================================

DJANGO_APPS = [
    "jazzmin",
    "django.contrib.admin",
    "django.contrib.auth",
    "django.contrib.contenttypes",
    "django.contrib.sessions",
    "django.contrib.messages",
    "django.contrib.staticfiles",
]

THIRD_PARTY_APPS = [
    "rest_framework",
    "rest_framework_simplejwt", 
    "rest_framework_simplejwt.token_blacklist"
]

DEBUG_TOOLS = [
    'drf_spectacular',
]

LOCAL_APPS = [
    'apps.authentication',
    'apps.common',
    'apps.system_console',
    'apps.sales',
]
if DEBUG:
    INSTALLED_APPS = DJANGO_APPS + THIRD_PARTY_APPS + LOCAL_APPS + DEBUG_TOOLS
else:  
    INSTALLED_APPS = DJANGO_APPS + THIRD_PARTY_APPS + LOCAL_APPS





# =========================================================
# MIDDLEWARE
# =========================================================

MIDDLEWARE = [
     'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
]

WSGI_APPLICATION = 'project.wsgi.application'


# =========================================================
# TEMPLATES
# =========================================================
TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
            ],
        },
    },
]

ROOT_URLCONF = 'project.urls'



# =========================================================
# DATABASE
# =========================================================

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': BASE_DIR / 'db.sqlite3',
    }
}




# =========================================================
# INTERNATIONALIZATION
# =========================================================

LANGUAGE_CODE = 'en-us'

TIME_ZONE = 'UTC'

USE_I18N = True

USE_TZ = True



# =========================================================
# STATIC & MEDIA FILES
# =========================================================

STATIC_URL = "static/"

STATIC_ROOT = BASE_DIR / "static"


MEDIA_URL = "/media/"

MEDIA_ROOT = BASE_DIR / "media"



# # =========================================================
# # DJANGO DEFAULTS
# # =========================================================

DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"

AUTH_USER_MODEL = 'authentication.User'

# LOGIN_URL = "/auth/access-denied/"


AUTH_PASSWORD_VALIDATORS = [
    {
        'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator',
    },
]


# # =========================================================
# # DJANGO REST FRAMEWORK
# # =========================================================

REST_FRAMEWORK = {
   
    "DEFAULT_SCHEMA_CLASS": "drf_spectacular.openapi.AutoSchema",
    "DEFAULT_AUTHENTICATION_CLASSES": [
        "rest_framework_simplejwt.authentication.JWTAuthentication",
        "rest_framework.authentication.SessionAuthentication",
    ],
    "DEFAULT_PARSER_CLASSES": [
        "rest_framework.parsers.JSONParser",
        "rest_framework.parsers.FormParser",
        "rest_framework.parsers.MultiPartParser",
    ],
    "DEFAULT_THROTTLE_CLASSES": [
        "rest_framework.throttling.AnonRateThrottle",
    ],
    "DEFAULT_THROTTLE_RATES": {
        "anon": "10/min"
    }
}


# # =========================================================
# # SIMPLE JWT
# # =========================================================

SIMPLE_JWT = {
    "ACCESS_TOKEN_LIFETIME": config("ACCESS_TOKEN_LIFETIME", default=timedelta(minutes=5)),
    "REFRESH_TOKEN_LIFETIME": config("REFRESH_TOKEN_LIFETIME", default=timedelta(days=1)),
    "ROTATE_REFRESH_TOKENS": True,
}


# # =========================================================
# # DRF SPECTACULAR
# # =========================================================

SPECTACULAR_SETTINGS = {
    'TITLE': 'Effective Mobile',
    'DESCRIPTION': 'Test task for Effective Mobile',
    'VERSION': '1.0.0',
    'SERVE_INCLUDE_SCHEMA': False,
}


# # =========================================================
# # CORS
# # =========================================================

